const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');

const prisma = new PrismaClient();
const BACKUP_DIR = path.join(__dirname, '../backups/data');

async function exportTable(tableName, query) {
    console.log(`📦 Exporting ${tableName}...`);
    try {
        const data = await query();
        const filePath = path.join(BACKUP_DIR, `${tableName}.json`);
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
        console.log(`   ✅ Exported ${data.length} records to ${filePath}`);
    } catch (error) {
        console.error(`   ❌ Failed to export ${tableName}:`, error.message);
    }
}

async function main() {
    if (!fs.existsSync(BACKUP_DIR)) {
        fs.mkdirSync(BACKUP_DIR, { recursive: true });
    }

    console.log('🚀 Starting Data Export\n');

    await exportTable('audits', () => prisma.audit.findMany());
    await exportTable('findings', () => prisma.finding.findMany());
    await exportTable('proposals', () => prisma.proposal.findMany());

    await prisma.$disconnect();
    console.log('\n✅ Data export complete!');
}

main();
